# Bao cao tuan (2026-06-12 den 2026-06-19)

So tin moi trong tuan: 10

## Tin moi theo dia diem
| Dia diem | So tin |
| --- | --- |
| Hà Nội | 7 |
| Hồ Chí Minh | 1 |
| Hồ Chí Minh, Hà Nội | 1 |
| Đà Nẵng | 1 |