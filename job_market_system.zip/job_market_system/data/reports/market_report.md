# Bao cao phan tich thi truong viec lam IT

Tong so tin tuyen dung: 500

## Top ky nang duoc yeu cau
| Ky nang | So tin |
| --- | --- |
| AI | 53 |
| English | 23 |
| Java | 20 |
| Python | 20 |
| SQL | 19 |
| AWS | 18 |
| DevOps | 16 |
| JavaScript | 11 |
| Data Engineering | 10 |
| React | 10 |
| Data Analysis | 9 |
| Cloud | 8 |
| Agile | 8 |
| Api | 8 |
| Microservices | 8 |

## Luong trung vi theo vi tri (trieu VND)
| Vi tri | Luong trung vi |
| --- | --- |
| Technical Lead (Kotlin/ Java/ Spring Ecosystem) Upto $2000 | 43.8 |
| Mid-Snr Software Engineer | 37.5 |
| Kế Toán Tổng Hợp Ngân Hàng- Thu Nhập Upto 35 Triệu/tháng | 35.0 |
| User Acquisition Manager (Mobile App Global) Thu Nhập Từ 25 - 40 Triệu++ | 32.5 |
| Trưởng phòng Truyền thông Đối ngoại và Thương hiệu | 27.5 |
| Trưởng Phòng Marketing _B2B - Mạnh về Digital [Lương 25 đến 30 triệu] | 27.5 |
| Nghiên cứu phát triển đồ uống (upto 18tr) | 25.0 |
| Trưởng nhóm  nghiên cứu phát triển đồ uống (upto 25tr) | 25.0 |
| AI Engineer (Middle Level) (Thu Nhập 20-30 Triệu) | 25.0 |
| Backend Engineer (Middle+) (Thu Nhập 20-30 Triệu) | 25.0 |
| CHUYÊN VIÊN CONTENT VIDEO & LIVESTREAM | 25.0 |
| [Hà Nội] Nhân Viên Tăng Trưởng Phát Triển Tính Năng Sản Phẩm Phần mềm Bán Hàng | Thu Nhập Upto 30Tr/Tháng + Đầy Đủ Đãi Ngộ | 22.5 |
| Chuyên Viên Marcom | 22.5 |
| Chuyên Viên Digital Marketing (Facebook Ads, Google Ads) | 22.5 |
| Brand Manager | 22.5 |
| [Nha Khoa Medlatec] Trưởng nhóm Brand Marketing | 21.5 |
| Chuyên Viên Kinh Doanh B2B (Data Sẵn) - Lương Upto 30Tr/tháng | 20.0 |
| Trợ Lý Tư Vấn ERP (Yêu Cầu Tiếng Trung) | 20.0 |
| Chuyên Viên ADS Optimize (Digital Marketing) | 20.0 |
| Cán Bộ Phụ Trách Công Tác Marketing | 19.0 |
| Nhân viên R&D  (đồ uống-22tr) | 18.5 |
| Digital Marketing | 18.5 |
| Chuyên Viên Marketing | 17.5 |
| TRƯỞNG NHÓM DIGITAL MARKETING | 17.5 |
| Truyền Thông Thương Hiệu Thời Trang Thể Thao - up to 20M | 17.0 |
| Branding Executive - up to 20M | 17.0 |
| Chuyên Viên Quay Dựng (Video Editor) | 16.5 |
| Branding Executive - up to 19M | 16.5 |
| MARKETING PLANNER | 15.0 |
| Senior Video Editor (ĐI LÀM NGAY) | 15.0 |
| Growth Marketing Specialist - Chuyên Viên Tăng Trưởng | 15.0 |
| Chuyên Viên Video Editor | 15.0 |
| Head of Database Administration Section (Trưởng Bộ Phận) | 15.0 |
| Brand Executive | 14.0 |
| Content Creator | 14.0 |
| Nhân Viên SEO | 14.0 |
| CONTENT CREATOR (PERSONAL BRANDING) | 13.5 |
| Trưởng Nhóm Biên Tập/Content Leader (Thủ Đức Cũ) | 13.5 |
| Content Creator Tiktok | 13.5 |
| [Cầu Giấy] Video Editor tổng thu nhập 16 - 20 triệu/tháng | 13.0 |
| [HCM] Video Editor - thu nhập 16-18 triệu/tháng | 13.0 |
| [CONCENTRIX TUYỂN DỤNG] CONTENT MODERATOR – MẢNG MUSIC SOCIAL PLATFORM | 12.5 |
| [Hà Nội] Nhân Viên Truyền thông Marketing | 12.5 |
| [Cầu Giấy] Nhân Viên Content Ads Marketing | 12.5 |
| Chuyên Viên Sáng Tạo Nội Dung Tiktok | 12.5 |
| Java Developer – Pega System | 12.5 |
| CONTENT CREATOR | 12.5 |
| [Hà Nội] Nhân Viên Content Marketing thu nhập 15-18 triệu/tháng | 12.5 |
| [Nha Khoa Medlatec] Nhân Viên Content Marketing | 12.0 |
| NHÂN VIÊN MARKETING | 11.5 |
| Nhân Viên Thiết Kế Hình Ảnh Và Quay Dựng Video (Video Editor) | 11.5 |
| [TUYỂN GẤP] NHÂN VIÊN MEDIA | 11.5 |
| [HCM] VIDEO EDITOR | 11.5 |
| [HÀ NỘI] VIDEO EDITOR | 11.5 |
| [TUYỂN GẤP] CHUYÊN VIÊN MEDIA | 11.5 |
| [HCM] CHUYÊN VIÊN MEDIA | 11.5 |
| Kiểm Duyệt Nội Dung - Mạng Xã Hội (Đào Tạo Đầu Vào) | 11.0 |
| NHÂN VIÊN DIGITAL MARKETING (HÀ NỘI - ĐI LÀM NGAY) | 11.0 |
| NHÂN VIÊN CONTENT | 11.0 |
| Nhân Viên Content Creator Ngành Hàng Nail | 11.0 |
| [Quận 12] NV Kiểm Duyệt Nội Dung - Nền Tảng Xã Hội - Tiếng Anh | 11.0 |
| [Quận 12] Content Moderator - Social Platform - 100% Tiếng Anh - Không Yêu Cầu Kinh Nghiệm | 11.0 |
| Content Moderator - Music Social Platform Q12 | 11.0 |
| Content Moderator - Music Social Platform | 11.0 |
| Nhân Viên Chạy Ads - Performance MKT (Đi Làm Ngay) | 11.0 |
| [Q12] Nhân Viên Kiểm Duyệt Nội Dung - Ứng Dụng Âm Nhạc | 11.0 |
| [TUYỂN DỤNG] CONTENT MODERATOR – DỰ ÁN MẠNG XÃ HỘI PHỔ BIẾN | 11.0 |
| [Q12] Content Moderator - Kiểm duyệt Nội dung - Ứng dụng Âm nhạc | 11.0 |
| Nhân Viên Kiểm Duyệt Nội Dung Âm Nhạc (Tiếng Anh giao tiếp) - Không yêu cầu kinh nghiệm | 11.0 |
| Nhân Viên Kiểm Duyệt Nội Dung - Ứng Dụng Âm Nhạc - Tiếng Anh giao tiếp | 11.0 |
| Nhân Viên VJ Ngành Hàng Nails Và Bánh | 11.0 |
| TUYỂN DỤNG NHÂN SỰ KIỂM DUYỆT NỘI DUNG (CONTENT MODERATOR) – NỀN TẢNG MẠNG XÃ HỘI | 11.0 |
| Nhân Viên Marketing Online | 10.5 |
| Hà Tĩnh - Chuyên Viên Hỗ Trợ Kinh Doanh | 10.0 |
| Nhân Viên Marketing | 10.0 |
| NHÂN VIÊN TRADE - MARKETING | 10.0 |
| Content Ads | 10.0 |
| MEDIA EXECUTIVE | 9.0 |
| [HN] Nhân Viên Content Marketing (Tuyển Gấp) | 9.0 |
| IDEA CREATOR (SELLER POD) - US & EU | 9.0 |
| Content Moderation - Ca Làm Cố Định | 9.0 |
| Chuyên Viên Kiểm Soát Nội Dung Sàn TMĐT - Tiếng Anh | 9.0 |
| Chuyên Viên Kiểm Soát Nội Dung - Sàn TMĐT | 9.0 |
| HCM - Marketing Staff | 9.0 |
| [HN] Chuyên Viên Marketing Online (Content, Social Media) (Tuyển Gấp) | 9.0 |
| Nhân Viên Content Marketing- Tiếng Anh | 8.5 |
| CHUYÊN VIÊN SEO WEBSITE | 8.5 |
| Idea Creator ( Seller POD) | 8.0 |
| NHÂN VIÊN SEO | 8.0 |
| Nhân Viên Admin Trực Page - Làm Giờ Hành Chính - Khu Vực Cầu Giấy - Hà Nội | 7.5 |
| Nhân Viên Văn Phòng Seeding Trực Page - Làm Giờ Hành Chính - Khu Vực Cầu Giấy - Hà Nội | 7.5 |
| [Quận 12] NHÂN VIÊN KIỂM DUYỆT NỘI DUNG - ỨNG DỤNG ÂM NHẠC - TIẾNG ANH - CÓ ĐÀO TẠO | 6.0 |
| NHÂN VIÊN CONTENT MAKETING | 6.0 |
| [Vũng Tàu] Thực tập sinh Marketing | 3.5 |
| [Vinh] Thực tập sinh Marketing | 3.5 |
| [Hải Phòng] Thực tập sinh Marketing | 3.5 |
| HỌC VIỆC CONTENT TIKTOK | 3.0 |
| Thực Tập Sinh Content Marketing | 3.0 |
| THỰC TẬP SINH CONTENT TIKTOK | 1.0 |
| Technical Leader (NodeJS / Golang / PHP) | 0.2 |

## Phan bo theo cap bac
| Cap bac | So tin |
| --- | --- |
| Entry | 500 |

## Phan bo theo dia diem
| Dia diem | So tin |
| --- | --- |
| Hà Nội | 160 |
| Hồ Chí Minh | 154 |
| Ho Chi Minh | 49 |
| Ha Noi | 34 |
| Đà Nẵng | 29 |
| Bình Dương | 9 |
| Hồ Chí Minh, Hà Nội | 8 |
| Ho Chi Minh - Ha Noi | 7 |
| Đồng Nai | 7 |
| Bắc Ninh | 4 |
| Nghệ An | 3 |
| Kiên Giang | 2 |
| Da Nang | 2 |
| Bà Rịa - Vũng Tàu | 2 |
| Long An | 2 |
| Others | 2 |
| Ho Chi Minh - Others | 2 |
| Ha Noi - Da Nang - Ho Chi Minh | 1 |
| Da Nang - Ha Noi | 1 |
| Bình Thuận | 1 |
| Hà Nội, Bắc Ninh | 1 |
| Hà Nội, Hồ Chí Minh | 1 |
| Hà Nội Hồ Chí Minh | 1 |
| Hà Nam | 1 |
| Ho Chi Minh - Da Nang | 1 |
| Hồ Chí Minh, Hà Nội, Đà Nẵng | 1 |
| Hồ Chí Minh Bà Rịa - Vũng Tàu | 1 |
| Hưng Yên, Hải Dương, Hà Nội | 1 |
| Hải Phòng | 1 |
| Hưng Yên | 1 |
| Hà Tĩnh | 1 |
| Khánh Hòa | 1 |
| Hồ Chí Minh, Đồng Nai | 1 |
| Kuala Lumpur | 1 |
| Hồ Chí Minh, Thừa Thiên- Huế | 1 |
| Others - Ho Chi Minh - Ha Noi | 1 |
| Quảng Nam Đà Nẵng | 1 |
| Thành Phố Huế | 1 |
| Quảng Ninh | 1 |
| Vĩnh Phúc | 1 |
| Vietnam | 1 |

## Goi y ky nang nen hoc
| Ky nang | Nhu cau | Luong TB | Diem |
| --- | --- | --- | --- |
| AI | 53 | 25.0 | 1325.0 |
| Java | 20 | 28.2 | 564.0 |
| Kotlin | 3 | 43.8 | 131.4 |
| Spring | 3 | 43.8 | 131.4 |
| English | 23 | 0.0 | 23.0 |
| Python | 20 | 0.0 | 20.0 |
| SQL | 19 | 0.0 | 19.0 |
| AWS | 18 | 0.0 | 18.0 |
| DevOps | 16 | 0.0 | 16.0 |
| JavaScript | 11 | 0.0 | 11.0 |

## Khoang cach ky nang (nen bo sung)
| Ky nang | Nhu cau | Luong TB | Diem |
| --- | --- | --- | --- |
| AI | 53 | 25.0 | 1325.0 |
| Java | 20 | 28.2 | 564.0 |
| Kotlin | 3 | 43.8 | 131.4 |
| Spring | 3 | 43.8 | 131.4 |
| English | 23 | 0.0 | 23.0 |
| Python | 20 | 0.0 | 20.0 |
| SQL | 19 | 0.0 | 19.0 |
| AWS | 18 | 0.0 | 18.0 |

## Bieu do
- skill_demand: /vercel/sandbox/data/job_market_extract/job_market_system/data/charts/skill_demand.png
- location: /vercel/sandbox/data/job_market_extract/job_market_system/data/charts/location.png
- salary_box: /vercel/sandbox/data/job_market_extract/job_market_system/data/charts/salary_box.png
- posting_trend: /vercel/sandbox/data/job_market_extract/job_market_system/data/charts/posting_trend.png